// tools/surfaces-studio/studio.js
import { $ } from './modules/dom.js';
import { toast } from './modules/toast.js';
import { createStudioState } from './modules/state.js';
import { initTabs } from './modules/tabs.js';
import { initCanvas } from './modules/canvas.js';
import { initSlotDesigner } from './modules/slotDesigner.js';
import { initExporter } from './modules/exporter.js';

import { initLiveHooks } from './modules/liveHooks.js';
import { initPartsComposer } from './modules/partsComposer.js';
import { initDataBrowser } from './modules/dataBrowser.js';
import { initPartSandbox } from './modules/partSandbox.js';
import { initJourneyRunner } from './modules/journeyRunner.js';
import { initValidate } from './modules/validate.js';

import { loadStudioState, saveStudioState } from './modules/persist.js';

const state = createStudioState();

// DEV: expose studio state for debugging (safe; this tool is local-only)
window.__STUDIO__ = window.__STUDIO__ || {};
window.__STUDIO__.state = state;
console.log('[Surfaces Studio] state exposed at window.__STUDIO__.state');

function syncSurfaceTypeUI() {
  $('#segScreen')?.classList.toggle('isOn', state.surfaceType === 'screen');
  $('#segModal')?.classList.toggle('isOn', state.surfaceType === 'modal');
  $('#segScreen')?.setAttribute('aria-selected', state.surfaceType === 'screen' ? 'true' : 'false');
  $('#segModal')?.setAttribute('aria-selected', state.surfaceType === 'modal' ? 'true' : 'false');
}

function wireSurfacePicker() {
  $('#segScreen')?.addEventListener('click', () => {
    state.surfaceType = 'screen';
    syncSurfaceTypeUI();
    state.emit('surfaceChanged');
  });

  $('#segModal')?.addEventListener('click', () => {
    state.surfaceType = 'modal';
    syncSurfaceTypeUI();
    state.emit('surfaceChanged');
  });

  const inp = $('#surfaceId');
  if (inp) {
    inp.value = state.surfaceId || '';
    inp.addEventListener('change', () => {
      state.surfaceId = (inp.value || '').trim() || 'hub';
      state.emit('surfaceChanged');
    });
  }
}

function wirePresetControls() {
  // Keep your existing baseline behavior; canvas.js owns actual sizing.
  const preset = $('#preset');
  const wrap = $('#customSizeWrap');
  const w = $('#customW');
  const h = $('#customH');

  function applyPreset() {
    const v = preset?.value || 'mobile-390x844';
    if (v === 'custom') {
      wrap && (wrap.hidden = false);
      state.baseW = parseInt(w?.value || '390', 10);
      state.baseH = parseInt(h?.value || '844', 10);
    } else {
      wrap && (wrap.hidden = true);
      const m = v.match(/(\d+)x(\d+)/i);
      state.baseW = m ? parseInt(m[1], 10) : 390;
      state.baseH = m ? parseInt(m[2], 10) : 844;
    }
    state.emit('canvasChanged');
  }

  preset?.addEventListener('change', applyPreset);
  w?.addEventListener('change', applyPreset);
  h?.addEventListener('change', applyPreset);

  applyPreset();
}

function initPersistence() {
  const loaded = loadStudioState(state);
  if (loaded) toast('Loaded saved studio state');

  // Autosave on important changes
  const save = () => saveStudioState(state);

  state.on('surfaceChanged', save);
  state.on('canvasChanged', save);
  state.on('slotsChanged', save);
  state.on('partsChanged', save);

  // also save on tab change etc if needed later
}

function boot() {
  syncSurfaceTypeUI();
  wireSurfacePicker();
  wirePresetControls();

  initTabs(state);
  initCanvas(state);
  initSlotDesigner(state);
  initExporter(state);

  initLiveHooks(state);
  initPartsComposer(state);
  initDataBrowser(state);
  initPartSandbox(state);
  initJourneyRunner(state);
  initValidate(state);

  initPersistence();

  // initial render
  state.emit('render');
}

boot();
