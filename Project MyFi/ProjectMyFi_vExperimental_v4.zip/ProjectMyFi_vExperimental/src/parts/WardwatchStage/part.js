// src/parts/WardwatchStage/part.js
import { ensureCssLink, fetchText } from "../../runtime/assetLoader.js";

function $(root, sel) {
  return root.querySelector(sel);
}
function $all(root, sel) {
  return Array.from(root.querySelectorAll(sel));
}

function safeGet(vm, path, fallback) {
  try {
    const v = vm.get(path);
    return v === undefined ? fallback : v;
  } catch {
    return fallback;
  }
}

export default {
  async mount(ctx, mountEl) {
    // 1) Load CSS (NO build step required)
    await ensureCssLink(ctx.baseUrl, "./part.css");
    await ensureCssLink(ctx.baseUrl, "./uplift.css");

    // 2) Load baseline HTML
    const html = await fetchText(ctx.baseUrl, "./baseline.html");
    mountEl.innerHTML = html;

    // ===== DOM refs =====
    const stageEl = $(".WardwatchStage", ".wwStage") || mountEl;

    const normalWrap = $(mountEl, "[data-ww='normal']");   // world/events/loadout container
    const battleWrap = $(mountEl, "[data-ww='battle']");   // battle container

    const tabsWrap = $(mountEl, "[data-ww='tabs']");
    const tabBtns = $all(mountEl, "[data-ww-tab]");
    const panels = $all(mountEl, "[data-ww-panel]");

    const worldStatus = $(mountEl, "[data-ww='worldStatus']");
    const aidBtn = $(mountEl, "[data-ww='aidBtn']");

    const exitBtn = $(mountEl, "[data-ww='exitBtn']");
    const battleLog = $(mountEl, "[data-ww='battleLog']");
    const enemySlots = $(mountEl, "[data-ww='enemySlots']");
    const endureBtn = $(mountEl, "[data-ww='skillEndure']");
    const channelBtn = $(mountEl, "[data-ww='skillChannel']");

    // ===== Local UI state =====
    let activeTab = "world";
    let inBattle = false;
    let selectedEnemyId = null;

    function setTab(tabId) {
      activeTab = tabId;

      tabBtns.forEach((b) => {
        b.classList.toggle("is-active", b.getAttribute("data-ww-tab") === tabId);
      });

      panels.forEach((p) => {
        p.classList.toggle("is-hidden", p.getAttribute("data-ww-panel") !== tabId);
      });
    }

    function setBattleMode(on) {
      inBattle = !!on;

      // Battle replaces the entire stage content area (per spec)
      if (normalWrap) normalWrap.classList.toggle("is-hidden", inBattle);
      if (battleWrap) battleWrap.classList.toggle("is-hidden", !inBattle);

      // Tabs/carousel hidden during battle
      if (tabsWrap) tabsWrap.classList.toggle("is-hidden", inBattle);

      // Ensure stage doesn’t collapse weirdly
      stageEl.classList.toggle("wwStage--battle", inBattle);
    }

    function logLine(text) {
      if (!battleLog) return;
      const line = document.createElement("div");
      line.className = "wwLogLine";
      line.textContent = text;
      battleLog.prepend(line);

      // trim
      while (battleLog.children.length > 60) {
        battleLog.removeChild(battleLog.lastChild);
      }
    }

    function renderEnemies(encounter) {
      if (!enemySlots) return;

      const enemies = (encounter && encounter.enemies) ? encounter.enemies : [];
      enemySlots.innerHTML = "";

      const maxSlots = 3;
      for (let i = 0; i < maxSlots; i++) {
        const e = enemies[i];
        const card = document.createElement("button");
        card.type = "button";
        card.className = "wwEnemyCard";

        if (!e) {
          card.classList.add("is-empty");
          card.disabled = true;
          card.innerHTML = `
            <div class="wwEnemyName">—</div>
            <div class="wwEnemyMeta">empty</div>
          `;
        } else {
          const isSel = selectedEnemyId === e.id || (!selectedEnemyId && i === 0);
          if (!selectedEnemyId && i === 0) selectedEnemyId = e.id;

          card.classList.toggle("is-selected", isSel);
          card.innerHTML = `
            <div class="wwEnemyName">${e.name}</div>
            <div class="wwEnemyMeta">HP ${e.hp} · Pressure ${encounter.pressureTotal}</div>
          `;
          card.addEventListener("click", () => {
            selectedEnemyId = e.id;
            // re-render selection state
            renderEnemies(encounter);
          });
        }

        enemySlots.appendChild(card);
      }
    }

    function renderFromVM() {
      const stage = safeGet(ctx.vm, "hub.stage", {});
      const encounter = stage.encounter || null;
      const mode = stage.mode || "world"; // "world" | "battle"

      // World status + CTA
      if (worldStatus) {
        if (!encounter) worldStatus.textContent = "All quiet — the ward holds.";
        else worldStatus.textContent = "Encounter present — manual window open";
      }

      if (aidBtn) {
        const showAid = !!encounter && mode !== "battle";
        aidBtn.classList.toggle("is-hidden", !showAid);
      }

      // Battle mode
      setBattleMode(mode === "battle");

      // When in battle, show dummy enemies and log
      if (mode === "battle") {
        // Ensure we always have something testable
        const effectiveEncounter = encounter || {
          pressureTotal: 8,
          enemies: [
            { id: "e1", name: "Cost", hp: 4 },
            { id: "e2", name: "Spike", hp: 3 },
          ],
        };

        renderEnemies(effectiveEncounter);
        if (battleLog && battleLog.children.length === 0) {
          logLine("Battle joined.");
          logLine(`Pressure owed: ${effectiveEncounter.pressureTotal}.`);
        }
      }
    }

    // ===== Wiring =====
    // Tabs
    tabBtns.forEach((b) => {
      b.addEventListener("click", () => {
        const tabId = b.getAttribute("data-ww-tab");
        setTab(tabId);
      });
    });
    setTab(activeTab);

    // Aid button → enter battle
    if (aidBtn) {
      aidBtn.addEventListener("click", () => {
        // Must be allowed by contract.json
        ctx.actions.emit("hub.enterBattle");
        inBattle = true;
        // render immediately for responsiveness
        renderFromVM();
      });
    }

    // Exit battle
    if (exitBtn) {
      exitBtn.addEventListener("click", () => {
        ctx.actions.emit("hub.exitBattle");
        inBattle = false;
        renderFromVM();
      });
    }

    // Skills (v1: just log + placeholder behavior)
    if (endureBtn) {
      endureBtn.addEventListener("click", () => {
        logLine(`Endure used on ${selectedEnemyId || "oldest enemy"}.`);
      });
    }
    if (channelBtn) {
      channelBtn.addEventListener("click", () => {
        logLine(`Channel used on ${selectedEnemyId || "oldest enemy"}.`);
      });
    }

    // Initial render
    renderFromVM();

    // NOTE: core skeleton doesn’t auto-re-render on vm mutations,
    // so we do a light polling refresh to keep demo behavior coherent.
    const interval = setInterval(renderFromVM, 250);

    return {
      unmount() {
        clearInterval(interval);
      },
    };
  },
};
