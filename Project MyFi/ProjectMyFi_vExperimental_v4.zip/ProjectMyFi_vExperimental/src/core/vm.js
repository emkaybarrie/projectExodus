// src/core/vm.js
function getByPath(obj, path) {
  if (!path) return obj;
  const parts = path.split(".");
  let cur = obj;
  for (const p of parts) {
    if (cur == null) return undefined;
    cur = cur[p];
  }
  return cur;
}

function setByPath(obj, path, value) {
  if (!path) return value;
  const parts = path.split(".");
  const out = Array.isArray(obj) ? obj.slice() : { ...(obj || {}) };

  let cur = out;
  for (let i = 0; i < parts.length; i++) {
    const key = parts[i];
    const isLast = i === parts.length - 1;

    const next = cur[key];
    if (isLast) {
      cur[key] = value;
    } else {
      const nextObj =
        next && typeof next === "object"
          ? (Array.isArray(next) ? next.slice() : { ...next })
          : {};
      cur[key] = nextObj;
      cur = nextObj;
    }
  }
  return out;
}

export function createVM(initialState = {}) {
  let state = initialState;
  const watchers = new Set();

  function notify() {
    for (const fn of watchers) {
      try {
        fn(state);
      } catch (e) {
        console.error("[vm] watcher error", e);
      }
    }
  }

  return {
    get(path = "") {
      return getByPath(state, path);
    },

    set(path, value) {
      state = setByPath(state, path, value);
      notify();
    },

    watch(fn) {
      watchers.add(fn);
      return () => watchers.delete(fn);
    },

    snapshot() {
      return state;
    },
  };
}
