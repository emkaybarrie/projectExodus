// src/dev/demo-vm.js
// Demo VM factory for the Hub surface.
// app.js expects: import { makeDemoHubVM } from "./dev/demo-vm.js";

export function makeDemoHubVM() {
  return {
    status: { label: "Ahead" },
    vitals: {
      health: { cur: 276, max: 276 },
      mana: { cur: 415, max: 415 },
      stamina: { cur: 691, max: 691 },
      shield: { cur: 1382, max: 1382 }
    },
    essence: { cur: 0, max: 1382 },

    stage: {
      page: "world",
      mode: "normal",
      auto: false,
      atbMs: 2600,

      loadout: {
        slots: ["Endure", "Channel", "—", "—"]
      },

      recentEncounters: [
        { name: "Cost", when: "Earlier", leak: 24 },
        { name: "Bill", when: "Yesterday", leak: 12 },
        { name: "Price", when: "2d", leak: 2 }
      ],

      encounter: {
        owedTotal: 8,
        enemies: [
          { id: "e1", name: "Cost", hp: 3, pressure: 5 },
          { id: "e2", name: "Spike", hp: 2, pressure: 3 }
        ]
      },

      battleLog: [
        "Encounter present — manual window open",
        "Cost presses the wardline…"
      ],

      targetEnemyId: "e1"
    }
  };
}

// Optional: legacy alias in case other files still import buildDemoVM()
export function buildDemoVM() {
  return { hub: makeDemoHubVM() };
}
