MyFi Skeleton (from V18.5)

- UI units live in: src/parts/{primitives|prefabs}/<Kind>/
- Surfaces live in: src/surfaces/{screens|modals}/<surfaceId>/
- Screens are thin wrappers that mount surfaces via core/surface.js.

This skeleton ships with a single placeholder part: EmptyCard.
Edit each surface.json to compose real slots + parts.
