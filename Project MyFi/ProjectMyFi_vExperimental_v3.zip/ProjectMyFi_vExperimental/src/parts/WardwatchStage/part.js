export default function WardwatchStage(ctx, { stage, vitals }) {
  const el = ctx.partRoot;

  const q = (hook) => el.querySelector(`[data-hook="${hook}"]`);

  const normalWrap = q("normalWrap");
  const battleWrap = q("battleWrap");

  const btnWorld = q("btnWorld");
  const btnEvents = q("btnEvents");
  const btnLoadout = q("btnLoadout");

  const pageWorld = q("pageWorld");
  const pageEvents = q("pageEvents");
  const pageLoadout = q("pageLoadout");

  const worldStatus = q("worldStatus");
  const btnAid = q("btnAid");
  const enemyChips = q("enemyChips");

  const eventsList = q("eventsList");
  const btnToggleAuto = q("btnToggleAuto");
  const loadoutSlots = q("loadoutSlots");

  const battleEnemySlots = q("battleEnemySlots");
  const btnExitBattle = q("btnExitBattle");
  const btnEndure = q("btnEndure");
  const btnChannel = q("btnChannel");
  const battleLog = q("battleLog");
  const atbFill = q("atbFill");

  let rafAtb = 0;

  function setPage(next) {
    stage.page = next;

    btnWorld.classList.toggle("isActive", next === "world");
    btnEvents.classList.toggle("isActive", next === "events");
    btnLoadout.classList.toggle("isActive", next === "loadout");

    pageWorld.classList.toggle("isActive", next === "world");
    pageEvents.classList.toggle("isActive", next === "events");
    pageLoadout.classList.toggle("isActive", next === "loadout");
  }

  function setMode(next) {
    stage.mode = next;

    const inBattle = next === "battle";
    normalWrap.classList.toggle("isHidden", inBattle);
    battleWrap.classList.toggle("isActive", inBattle);

    if (!inBattle) stopAtb();
    if (inBattle) startAtb();
  }

  function renderWorld() {
    const hasEncounter = !!stage.encounter && stage.encounter.owedTotal > 0;

    worldStatus.textContent = hasEncounter
      ? "Encounter present — manual window open"
      : "All quiet.";

    btnAid.classList.toggle("isVisible", hasEncounter);

    enemyChips.innerHTML = "";
    const enemies = (stage.encounter?.enemies || []).slice(0, 3);
    for (const e of enemies) {
      const chip = document.createElement("div");
      chip.className = "wwChip";
      chip.textContent = `${e.name}`;
      enemyChips.appendChild(chip);
    }
  }

  function renderEvents() {
    eventsList.innerHTML = "";
    const list = stage.recentEncounters || [];
    if (!list.length) {
      const row = document.createElement("div");
      row.className = "wwEventRow";
      row.textContent = "No recent encounters.";
      eventsList.appendChild(row);
      return;
    }

    for (const it of list.slice(0, 6)) {
      const row = document.createElement("div");
      row.className = "wwEventRow";
      row.innerHTML = `
        <div>${it.name}</div>
        <div>${it.when} · Leak ${it.leak}</div>
      `;
      eventsList.appendChild(row);
    }
  }

  function renderLoadout() {
    const auto = !!stage.auto;
    btnToggleAuto.textContent = auto ? "ON" : "OFF";

    loadoutSlots.innerHTML = "";
    const slots = stage.loadout?.slots || ["Endure", "Channel", "—", "—"];
    for (const s of slots) {
      const chip = document.createElement("div");
      chip.className = "wwChip";
      chip.textContent = s;
      loadoutSlots.appendChild(chip);
    }
  }

  function renderBattle() {
    const encounter = stage.encounter;
    const enemies = encounter?.enemies || [];

    battleEnemySlots.innerHTML = "";
    for (let i = 0; i < 3; i++) {
      const e = enemies[i];
      const card = document.createElement("div");
      card.className = "wwEnemyCard";

      if (!e) {
        card.textContent = "— empty";
        card.style.opacity = "0.55";
      } else {
        card.innerHTML = `
          <div style="font-weight:900">${e.name}</div>
          <div style="opacity:.85; font-size:12px">HP ${e.hp} · Pressure ${e.pressure}</div>
        `;
        if (stage.targetEnemyId && stage.targetEnemyId === e.id) {
          card.classList.add("isTarget");
        }
        card.addEventListener("click", () => {
          stage.targetEnemyId = e.id;
          renderBattle();
        });
      }

      battleEnemySlots.appendChild(card);
    }

    battleLog.textContent = (stage.battleLog || []).slice(-6).join("\n");
  }

  function pushLog(line) {
    stage.battleLog = stage.battleLog || [];
    stage.battleLog.push(line);
    if (stage.battleLog.length > 60) stage.battleLog = stage.battleLog.slice(-60);
    renderBattle();
  }

  // Simple ATB fill: fills over stage.atbMs (defaults)
  function startAtb() {
    stopAtb();
    const atbMs = stage.atbMs || 2600;
    const t0 = performance.now();

    const tick = (t) => {
      const pct = Math.min(1, (t - t0) / atbMs);
      atbFill.style.width = `${Math.floor(pct * 100)}%`;
      if (pct < 1) {
        rafAtb = requestAnimationFrame(tick);
      } else {
        // When ATB completes, if player does nothing, treat as "auto"
        atbFill.style.width = "0%";
        pushLog("Time passes… (auto decision placeholder)");
        startAtb();
      }
    };

    rafAtb = requestAnimationFrame(tick);
  }

  function stopAtb() {
    if (rafAtb) cancelAnimationFrame(rafAtb);
    rafAtb = 0;
    atbFill.style.width = "0%";
  }

  function useSkill(kind) {
    const encounter = stage.encounter;
    if (!encounter) return;

    const enemies = encounter.enemies || [];
    const target =
      enemies.find((e) => e.id === stage.targetEnemyId) ||
      enemies[0];

    if (!target) return;

    // v1: spend 1 unit and reduce owedTotal by 1; reduce enemy hp by 1
    encounter.owedTotal = Math.max(0, encounter.owedTotal - 1);
    target.hp = Math.max(0, target.hp - 1);

    pushLog(`${kind} used on ${target.name}. (-1 owed)`);
    renderBattle();

    // resolve / exit if owedTotal hits 0
    if (encounter.owedTotal === 0) {
      pushLog("Encounter resolved. Returning to patrol…");
      setTimeout(() => {
        setMode("normal");
        setPage("world");
      }, 450);
    }
  }

  // ===== bindings =====
  btnWorld?.addEventListener("click", () => setPage("world"));
  btnEvents?.addEventListener("click", () => setPage("events"));
  btnLoadout?.addEventListener("click", () => setPage("loadout"));

  btnAid?.addEventListener("click", () => {
    // Switch locally (no guardrails action call)
    setMode("battle");
    renderBattle();
  });

  btnExitBattle?.addEventListener("click", () => {
    setMode("normal");
    setPage("world");
  });

  btnToggleAuto?.addEventListener("click", () => {
    stage.auto = !stage.auto;
    renderLoadout();
  });

  btnEndure?.addEventListener("pointerup", () => useSkill("Endure"));
  btnChannel?.addEventListener("pointerup", () => useSkill("Channel"));

  // ===== init =====
  stage.page = stage.page || "world";
  stage.mode = stage.mode || "normal";
  stage.battleLog = stage.battleLog || [];

  setPage(stage.page);
  setMode(stage.mode);

  // Title/desc driven by stage state (basic v1)
  const titleEl = q("title");
  const descEl = q("desc");
  const owed = stage.encounter?.owedTotal || 0;

  if (titleEl) titleEl.textContent = owed > 0 ? "Wardwatch — Encounter" : "Wardwatch — Quiet";
  if (descEl) descEl.textContent = owed > 0
    ? "A disturbance presses against the wardline. You can intervene, or let your setup handle it."
    : "The ward holds. Soft embers drift on the skyline.";

  renderWorld();
  renderEvents();
  renderLoadout();
  renderBattle();
}
