export function getDataMode() {
  // Later: read from querystring/localStorage/build flag
  return "demo";
}
