import { ensureCssLink, fetchText, mapHooks } from "../../runtime/assetLoader.js";

// WardwatchStage
// - World / Events / Loadout tabs (swipe optional later)
// - World view shows patrol or battle-context still + VFX
// - If an encounter exists, world view offers an "Aid Your Avatar" CTA
// - "Aid" enters Battle Mode: tabs collapse and Stage shows battle scaffold
// NOTE: This is a V1 scaffold. The full battle engine (pressure invariants,
// actor timers, targeting, etc.) will be wired next.

export const WardwatchStage = {
  async mount({ el, ctx }) {
    // 1) Load uplift CSS (no build step)
    await ensureCssLink("./src/parts/WardwatchStage/uplift.css", "css-part-WardwatchStage");

    // 2) Load baseline HTML
    const html = await fetchText("./src/parts/WardwatchStage/baseline.html");
    el.innerHTML = html;

    const hooks = mapHooks(el);

    // Local UI state (kept out of VM for now)
    let activeTab = "world"; // "world" | "events" | "loadout"

    function setTab(next) {
      activeTab = next;

      // Tabs
      hooks.tabWorld?.classList.toggle("isActive", next === "world");
      hooks.tabEvents?.classList.toggle("isActive", next === "events");
      hooks.tabLoadout?.classList.toggle("isActive", next === "loadout");

      // Pages
      hooks.pageWorld?.classList.toggle("isActive", next === "world");
      hooks.pageEvents?.classList.toggle("isActive", next === "events");
      hooks.pageLoadout?.classList.toggle("isActive", next === "loadout");
    }

    hooks.tabWorld?.addEventListener("click", () => setTab("world"));
    hooks.tabEvents?.addEventListener("click", () => setTab("events"));
    hooks.tabLoadout?.addEventListener("click", () => setTab("loadout"));

    // Actions
    hooks.btnOpenLoadout?.addEventListener("click", () => ctx.actions.hub.openLoadout());
    hooks.btnOpenRecent?.addEventListener("click", () => ctx.actions.hub.openRecent());

    hooks.btnAid?.addEventListener("click", () => ctx.actions.hub.enterBattle());
    hooks.btnExitBattle?.addEventListener("click", () => ctx.actions.hub.exitBattle());

    hooks.btnAuto?.addEventListener("click", () => ctx.actions.battle.toggleAuto());
    hooks.btnAutoBattle?.addEventListener("click", () => ctx.actions.battle.toggleAuto());

    hooks.btnEndure?.addEventListener("click", () => ctx.actions.battle.endure());
    hooks.btnChannel?.addEventListener("click", () => ctx.actions.battle.channel());

    function renderRecent(list) {
      if (!hooks.recentList) return;
      hooks.recentList.innerHTML = "";

      const items = Array.isArray(list) ? list.slice(0, 3) : [];
      if (!items.length) {
        const row = document.createElement("div");
        row.className = "wwRecentRow";
        row.innerHTML = `<span><b>—</b></span><span>Nothing yet</span>`;
        hooks.recentList.appendChild(row);
        return;
      }

      for (const it of items) {
        const row = document.createElement("div");
        row.className = "wwRecentRow";
        row.innerHTML = `<span><b>${it?.name ?? "Encounter"}</b></span><span>${it?.summary ?? ""}</span>`;
        hooks.recentList.appendChild(row);
      }
    }

    function renderEnemyPips(encounters) {
      if (!hooks.worldEnemies) return;
      hooks.worldEnemies.innerHTML = "";

      const list = Array.isArray(encounters) ? encounters.slice(0, 3) : [];
      for (const e of list) {
        const pip = document.createElement("div");
        pip.className = "wwEnemyPip";
        pip.textContent = e?.label ?? "Enemy";
        hooks.worldEnemies.appendChild(pip);
      }
    }

    function renderBattleEnemies(encounters) {
      if (!hooks.battleEnemies) return;
      hooks.battleEnemies.innerHTML = "";

      const list = Array.isArray(encounters) ? encounters.slice(0, 3) : [];
      const padded = list.concat([null, null, null]).slice(0, 3);

      for (const e of padded) {
        const card = document.createElement("div");
        card.className = "wwEnemyCard";
        if (!e) {
          card.innerHTML = `<b>—</b><div class="muted">empty</div>`;
        } else {
          card.innerHTML = `<b>${e.name ?? "Enemy"}</b><div class="muted">Pressure: ${e.pressure ?? "?"}</div>`;
        }
        hooks.battleEnemies.appendChild(card);
      }
    }

    function renderBattleLog(lines) {
      if (!hooks.battleLog) return;
      hooks.battleLog.innerHTML = "";

      const list = Array.isArray(lines) ? lines.slice(-12).reverse() : [];
      if (!list.length) {
        const div = document.createElement("div");
        div.className = "line";
        div.textContent = "No battle log yet.";
        hooks.battleLog.appendChild(div);
        return;
      }

      for (const line of list) {
        const div = document.createElement("div");
        div.className = "line";
        div.textContent = line;
        hooks.battleLog.appendChild(div);
      }
    }

    function render(stage, ghost) {
      const mode = stage?.mode ?? "patrol";
      const battleOpen = !!stage?.battleOpen;

      // Global header bits
      if (hooks.title) hooks.title.textContent = mode === "battle" ? "Wardwatch — Encounter" : "Wardwatch — All quiet";
      if (hooks.subtitle) {
        hooks.subtitle.textContent =
          mode === "battle"
            ? "A disturbance presses against the wardline. You can intervene, or let your setup handle it."
            : "The ward holds. Soft embers drift on the skyline.";
      }

      if (hooks.ghostHealth) hooks.ghostHealth.textContent = ghost?.healthIfLeak ?? "—";

      // CTA visibility: only when encounter exists AND not currently in battle view
      const hasEncounter = mode === "battle";
      hooks.btnAid?.classList.toggle("isHidden", !hasEncounter || battleOpen);

      // World caption
      if (hooks.worldCaption) {
        hooks.worldCaption.textContent =
          hasEncounter ? "Encounter present — manual window open" : "Patrol view — ambient";
      }

      // Auto labels
      const autoLabel = stage?.auto ? "ON" : "OFF";
      if (hooks.btnAuto) hooks.btnAuto.textContent = `Auto: ${autoLabel}`;
      if (hooks.loadoutAuto) hooks.loadoutAuto.textContent = autoLabel;

      // Recent list
      renderRecent(stage?.recent);

      // World pips + battle enemies
      renderEnemyPips(stage?.encounters);
      renderBattleEnemies(stage?.encounters);

      // Battle stats (placeholder values, later we’ll bind to real vitals)
      if (hooks.bHealth) hooks.bHealth.textContent = ghost?.healthIfLeak ?? "—";
      if (hooks.bMana) hooks.bMana.textContent = "—";
      if (hooks.bStam) hooks.bStam.textContent = "—";

      // Battle log
      renderBattleLog(stage?.battleLog);

      // Mode switching
      hooks.battleWrap?.classList.toggle("isActive", battleOpen);
      if (hooks.battleWrap) hooks.battleWrap.style.display = battleOpen ? "block" : "none";
      if (hooks.normalWrap) hooks.normalWrap.style.display = battleOpen ? "none" : "block";

      // Keep tab state stable when we return from battle
      if (!battleOpen) setTab(activeTab);
    }

    // Initial UI state
    setTab(activeTab);

    // Watch VM slices (guarded)
    const unwatchStage = ctx.vm.watchMapped("stage", (v) => {
      const ghost = ctx.vm.getMapped("ghost");
      render(v, ghost);
    });

    const unwatchGhost = ctx.vm.watchMapped("ghost", (v) => {
      const stage = ctx.vm.getMapped("stage");
      render(stage, v);
    });

    // First render
    render(ctx.vm.getMapped("stage"), ctx.vm.getMapped("ghost"));

    return {
      destroy() {
        unwatchStage?.();
        unwatchGhost?.();
        el.innerHTML = "";
      }
    };
  }
};
