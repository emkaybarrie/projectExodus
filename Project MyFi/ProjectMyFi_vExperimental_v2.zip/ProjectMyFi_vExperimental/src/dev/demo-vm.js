export function makeDemoHubVM() {
  return {
    hub: {
      status: { ahead: true, focusLabel: "Today" },
      vitals: {
        health: { cur: 276, max: 276 },
        mana:   { cur: 415, max: 415 },
        stam:   { cur: 691, max: 691 },
        shield: { cur: 1382, max: 1382, delta: +27 }
      },
      ghost: {
        healthAfterLeak: 252
      },
      stage: {
        mode: "patrol", // "patrol" | "battle"
        auto: true,
        scene: {
          title: "Wardwatch — All quiet",
          subtitle: "The ward holds. Soft embers drift on the skyline.",
          bgKey: "city-dusk-01"
        },
        recent: [
          { name: "Cost",  when: "Earlier",    result: "Leak 24", icon: "🜁" },
          { name: "Bill",  when: "Yesterday",  result: "Mit 12",  icon: "🛡️" },
          { name: "Price", when: "2d",         result: "Auto",    icon: "✦" }
        ]
      },
      essence: { cur: 0, max: 1382 }
    }
  };
}
