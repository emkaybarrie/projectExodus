// Dev-only contract validation helpers.
// Keeps AI (and humans) from inventing bindings, VM paths, or actions.

export function loadContractForPart(partId) {
  // Convention: contract lives at /src/parts/<PartId>/contract.json
  return fetch(`./src/parts/${partId}/contract.json`).then(async (r) => {
    if (!r.ok) throw new Error(`Missing contract.json for part: ${partId}`);
    return r.json();
  });
}

export function validateSurfacePlacement({ partId, placement }) {
  const bind = placement.bind || {};
  const errors = [];

  // Required binds present?
  for (const req of partId.contract.bindRequired || []) {
    if (!bind[req]) errors.push(`Part "${partId.id}" missing required bind "${req}" in surface.json`);
  }

  return errors;
}

// Creates a ctx wrapper that tracks reads/calls and enforces contract in dev.
export function wrapCtxWithContract({ ctx, partId, contract, bind }) {
  const dev = true;

  const allowedActionSet = new Set(contract.actionsAllowed || []);
  const allowedReadSet = new Set(contract.vmReads || []);
  const strictReads = !!contract.strictVmReads;

  const vm = ctx.vm;

  const vmProxy = {
    get(path) {
      if (dev && path && strictReads) {
        // allow reads of bound roots (e.g. "hub.stage") even if not explicitly listed
        const ok =
          allowedReadSet.has(path) ||
          [...allowedReadSet].some((p) => path.startsWith(p + ".")) ||
          isUnderBind(path, bind);

        if (!ok) {
          console.warn(`[contract] ${partId} read disallowed VM path: "${path}"`);
        }
      }
      return vm.get(path);
    },
    set(path, value) {
      // Writes are allowed (parts often toggle UI state),
      // but you can add strict write rules later if you want.
      return vm.set(path, value);
    },
    subscribe(fn) { return vm.subscribe(fn); },
    snapshot() { return vm.snapshot(); }
  };

  const actionsProxy = new Proxy(ctx.actions, {
    get(target, topKey) {
      const top = target[topKey];
      if (!top || typeof top !== "object") return top;

      return new Proxy(top, {
        get(obj, fnKey) {
          const fn = obj[fnKey];
          if (typeof fn !== "function") return fn;

          return (...args) => {
            const fq = `${String(topKey)}.${String(fnKey)}`;
            if (dev && allowedActionSet.size && !allowedActionSet.has(fq)) {
              console.warn(`[contract] ${partId} called disallowed action: "${fq}"`);
            }
            return fn(...args);
          };
        }
      });
    }
  });

  return { ...ctx, vm: vmProxy, actions: actionsProxy };
}

function isUnderBind(path, bind) {
  // If a part is bound to "hub.stage", allow "hub.stage.*" reads as “under bind”
  return Object.values(bind || {}).some((root) => {
    if (!root) return false;
    return path === root || path.startsWith(root + ".");
  });
}
