# Uplift Pack: EssenceFooter

## Rules
- You may edit ONLY: uplift.css
- Do NOT change baseline.html or hooks.
- Do NOT invent new data or actions.

## Goal
Make footer feel premium and consistent with the hub.

## Output
- Paste-back uplift.css only.
- If requesting new data, include contract + demo VM deltas.
