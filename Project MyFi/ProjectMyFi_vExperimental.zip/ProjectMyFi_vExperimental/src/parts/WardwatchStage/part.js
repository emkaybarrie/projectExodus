import { ensureCssLink, fetchText, mapHooks } from "../../runtime/assetLoader.js";

export default {
  async mount({ el, bind, ctx }) {
    // 1) Load uplift CSS once
    await ensureCssLink(
      "./src/parts/WardwatchStage/uplift.css",
      "css-WardwatchStage"
    );

    // 2) Inject locked baseline markup
    el.innerHTML = await fetchText("./src/parts/WardwatchStage/baseline.html");

    const root = el.querySelector(".Part-WardwatchStage");
    const hooks = mapHooks(root);

    const stagePath = bind.stage;
    const ghostPath = bind.ghost;

    // Wiring (locked behaviour)
    hooks.btnLoadout.addEventListener("click", () => ctx.actions.hub.openLoadout());
    hooks.btnRecent.addEventListener("click", () => ctx.actions.hub.openRecent());
    hooks.btnAuto.addEventListener("click", () => ctx.actions.battle.toggleAuto());

    function render() {
      const stage = ctx.vm.get(stagePath);
      const ghost = ctx.vm.get(ghostPath);
      if (!stage) return;

      hooks.title.textContent = stage.scene?.title ?? "Wardwatch";
      hooks.subtitle.textContent = stage.scene?.subtitle ?? "";
      hooks.ghostHealth.textContent = ghost?.healthAfterLeak ?? "—";
      hooks.btnAuto.textContent = `Auto: ${stage.auto ? "ON" : "OFF"}`;

      // Enemy placeholders for now
      hooks.enemyLayer.innerHTML = "";
      const count = stage.mode === "battle" ? (stage.enemyCount ?? 1) : 0;
      for (let i = 0; i < count; i++) {
        const d = document.createElement("div");
        d.className = "wwEnemy";
        hooks.enemyLayer.appendChild(d);
      }

      // Recent list
      hooks.recentRows.innerHTML = "";
      (stage.recent || []).slice(0, 3).forEach(r => {
        const row = document.createElement("div");
        row.className = "wwRecentRow";
        row.innerHTML = `
          <span class="wwIcon">${r.icon ?? "✦"}</span>
          <span class="wwName">${r.name ?? "—"}</span>
          <span class="wwMeta">${r.when ?? ""}</span>
          <span class="wwRes">${r.result ?? ""}</span>
        `;
        hooks.recentRows.appendChild(row);
      });
    }

    const unsub = ctx.vm.subscribe((changed) => {
      if (changed.startsWith(stagePath) || changed.startsWith(ghostPath)) render();
    });

    render();

    return {
      destroy() {
        unsub();
      }
    };
  }
};
