// src/ui/prefabs/QuestsHeader/part.js
// Mountable header for the Quests screen.
//
// Uplift pack rules:
// - baseline.html is locked.
// - uplift.html/uplift.css are editable and safe to delete to revert.

import { ensureGlobalCSS } from '../../../core/styleLoader.js';
import { loadTextOnce } from '../../../core/assetLoader.js';

async function loadTemplate(){
  // Always load uplift CSS (blank file = baseline)
  ensureGlobalCSS('QuestsHeader', new URL('./uplift.css', import.meta.url));

  const baselineUrl = new URL('./baseline.html', import.meta.url);
  const upliftUrl = new URL('./uplift.html', import.meta.url);

  // Prefer uplift.html if present; otherwise fallback to baseline.html.
  try {
    const html = await loadTextOnce('QuestsHeader.upliftHtml', upliftUrl);
    if (String(html || '').trim().length > 0) return html;
  } catch {}

  return await loadTextOnce('QuestsHeader.baselineHtml', baselineUrl);
}

/**
 * Surface part factory.
 * @param {HTMLElement} host
 */
export async function QuestsHeaderPart(host){
  host.innerHTML = await loadTemplate();
  return {
    unmount(){
      try { host.innerHTML = ''; } catch {}
    }
  };
}
