# QuestsHeader AI Uplift Pack (v1)

You may edit **ONLY**:
- `uplift.html`
- `uplift.css`

Non-negotiable rules:
1) Keep all `data-hook` attributes intact.
2) Do not change the meaning of hooks.
3) Do not add external dependencies.
4) CSS scope: every selector in `uplift.css` must start with `.Part-QuestsHeader`.
5) Output must be in paste-back format:

---FILE: uplift.html
<...>

---FILE: uplift.css
<...>
