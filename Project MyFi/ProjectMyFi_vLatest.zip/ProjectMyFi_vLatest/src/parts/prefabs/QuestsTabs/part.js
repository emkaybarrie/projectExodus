// src/ui/prefabs/QuestsTabs/part.js
// Mountable Quests tabs (type filter).

import { ensureGlobalCSS } from '../../../core/styleLoader.js';
import { loadTextOnce } from '../../../core/assetLoader.js';
import { mountSegmentTabs } from '../../primitives/SegmentTabs/part.js';

async function loadTemplate(){
  ensureGlobalCSS('QuestsTabs', new URL('./uplift.css', import.meta.url));

  const baselineUrl = new URL('./baseline.html', import.meta.url);
  const upliftUrl = new URL('./uplift.html', import.meta.url);

  try {
    const html = await loadTextOnce('QuestsTabs.upliftHtml', upliftUrl);
    if (String(html || '').trim().length > 0) return html;
  } catch {}
  return await loadTextOnce('QuestsTabs.baselineHtml', baselineUrl);
}

export async function QuestsTabsPart(host, { ctx = {} } = {}){
  const store = ctx?.quests;
  if (!store) throw new Error('QuestsTabsPart: missing ctx.quests store');

  host.innerHTML = await loadTemplate();

  const root = host.querySelector('.Part-QuestsTabs') || host;
  const tabsHost = root.querySelector('[data-hook=tabs]') || root;

  const types = store.types();
  const tabs = mountSegmentTabs(tabsHost, {
    ariaLabel: 'Quest types',
    buttonClass: 'qbTab',
    activeClass: 'is-active',
    items: [{ key:'all', label:'All' }, ...types.map(t => ({ key:t.key, label:t.label }))],
    initialKey: 'all',
    onSelect: (key) => store.setFilter(key),
  });

  return {
    unmount(){
      try { tabs?.unmount?.(); } catch {}
      try { host.innerHTML = ''; } catch {}
    }
  };
}
