# QuestsTabs AI Uplift Pack (v1)

You may edit **ONLY**:
- `uplift.html`
- `uplift.css`

Rules:
1) Keep `data-hook="tabs"` intact.
2) Do not add dependencies.
3) CSS scope: every selector in `uplift.css` must start with `.Part-QuestsTabs`.
4) Paste-back format:

---FILE: uplift.html
...

---FILE: uplift.css
...
