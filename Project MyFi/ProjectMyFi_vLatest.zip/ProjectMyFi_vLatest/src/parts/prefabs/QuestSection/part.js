// src/ui/prefabs/QuestSection/part.js
// Renders one quests section (Focused / Available / Completed).
//
// Model B: this is a library prefab (mountable via surface.json).
// It consumes state/actions from ctx.quests store.

import { ensureGlobalCSS } from '../../../core/styleLoader.js';
import { loadTextOnce } from '../../../core/assetLoader.js';
import { preloadObjectiveCardTemplate, renderObjectiveCard } from '../ObjectiveCard/part.js';

function sectionMeta(section){
  if (section === 'focused') return { title: 'Focused', empty: 'No focused quests yet.' };
  if (section === 'available') return { title: 'Available', empty: 'No available quests in this filter.' };
  return { title: 'Completed', empty: 'Nothing claimed yet.' };
}

async function loadTemplate(){
  ensureGlobalCSS('QuestSection', new URL('./uplift.css', import.meta.url));
  const baselineUrl = new URL('./baseline.html', import.meta.url);
  const upliftUrl = new URL('./uplift.html', import.meta.url);

  try {
    const html = await loadTextOnce('QuestSection.upliftHtml', upliftUrl);
    if (String(html || '').trim().length > 0) return html;
  } catch {}
  return await loadTextOnce('QuestSection.baselineHtml', baselineUrl);
}

export async function QuestSectionPart(host, { props = {}, ctx = {} } = {}){
  const store = ctx?.quests;
  if (!store) throw new Error('QuestSectionPart: missing ctx.quests store');

  const section = props.section || 'available';
  const meta = sectionMeta(section);

  host.innerHTML = await loadTemplate();
  const root = host.querySelector('.Part-QuestSection') || host;
  root.dataset.section = section;

  const titleEl = root.querySelector('[data-hook=title]');
  const listEl = root.querySelector('[data-hook=list]');
  if (titleEl) titleEl.textContent = meta.title;

  let unsub = null;

  function paint(){
    if (!listEl) return;
    const quests = store.selectBySection(section);
    listEl.innerHTML = '';
    if (!quests || quests.length === 0) {
      listEl.innerHTML = `<div class="qbEmpty">${meta.empty}</div>`;
      return;
    }
    for (const q of quests) {
      listEl.appendChild(renderObjectiveCard(q));
    }
  }

  function onClick(e){
    const btn = e.target?.closest?.('button[data-act]');
    if (!btn) return;
    const qid = btn.closest?.('.qbCard')?.dataset?.qid;
    if (!qid) return;
    const act = btn.dataset.act;
    if (act === 'focus') {
      store.toggleFocus(qid);
    }
    if (act === 'claim') {
      const detail = store.claim(qid);
      if (detail) {
        host.dispatchEvent(new CustomEvent('quests:claimed', { bubbles:true, detail }));
      }
    }
  }

  try { await preloadObjectiveCardTemplate(); } catch {}

  root.addEventListener('click', onClick);
  unsub = store.subscribe(() => paint());
  paint();

  return {
    unmount(){
      try { root.removeEventListener('click', onClick); } catch {}
      try { unsub?.(); } catch {}
      try { host.innerHTML = ''; } catch {}
    }
  };
}
