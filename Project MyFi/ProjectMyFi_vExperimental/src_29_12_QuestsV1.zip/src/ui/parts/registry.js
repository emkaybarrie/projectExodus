import SegmentedTabs from './SegmentedTabs/part.js';
import List from './List/part.js';
import QuestItem from './QuestItem/part.js';

export const partRegistry = {
  SegmentedTabs,
  List,
  QuestItem
};
