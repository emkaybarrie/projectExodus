Local incubator for hub-only logic before promotion to a feature pack.
Rules:
- No Firestore SDK calls.
- If used by 2+ screens, promote to feature pack.
- Add "PROMOTE?" header on non-trivial files.
