# MyFi Master Reference Changelog

## 2026-01-22
- Created initial MyFi Master Reference (v0.1) and Reference Index to enable automation-oriented monitoring.
