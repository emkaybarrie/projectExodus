# MyFi Master Reference (Non-Authoritative)

⚠️ This file is NOT the canonical MyFi reference.

The authoritative MyFi reference is maintained in:
- `/myfi/reference/MYFI_MASTER_REFERENCE.docx`

This markdown file exists only as:
- a convenience summary
- a human-readable snapshot
- or an export target

In case of conflict:
- The Word document wins
- The reference index (`MYFI_REFERENCE_INDEX.json`) defines sync rules

Do not update this file directly unless explicitly instructed by a Work Order.
