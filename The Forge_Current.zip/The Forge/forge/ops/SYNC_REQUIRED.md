# SYNC REQUIRED

## Reason
Describe why Director action is required.

## Required Actions
- [ ] Action 1
- [ ] Action 2

## Who triggered this
- Agent / CI / Director

## How to clear
Complete required actions and delete this file (or mark RESOLVED).

## Last updated
YYYY-MM-DD
