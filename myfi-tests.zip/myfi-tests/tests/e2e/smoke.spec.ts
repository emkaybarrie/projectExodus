import { test, expect } from './fixtures';

const EMAIL = process.env.SEED_EMAIL!;
const PASSWORD = process.env.SEED_PASSWORD!;

// Basic smoke run-through you can watch in headed mode
// - visit login
// - sign in
// - wait for splash to dismiss
// - assert HUD present
// - open a couple menus and verify key UI

test('smoke: login → splash → HUD visible → menus open', async ({ page }) => {
  await page.goto('/');

  // Login screen
  await expect(page.getByRole('heading', { name: /login/i })).toBeVisible({ timeout: 10_000 });
  await page.getByLabel(/email/i).fill(EMAIL);
  await page.getByLabel(/password/i).fill(PASSWORD);
  await page.getByRole('button', { name: /sign in/i }).click();

  // Splash should appear then fade
  await expect(page.locator('#splash')).toBeVisible();
  await expect(page.locator('#splash')).toBeHidden({ timeout: 12_000 });

  // HUD checks
  await expect(page.locator('#vitalsHUD')).toBeVisible();
  await expect(page.getByText(/stamina/i)).toBeVisible();
  await expect(page.getByText(/mana/i)).toBeVisible();
  await expect(page.getByText(/health/i)).toBeVisible();

  // Open Finances menu via modal
  // Replace this with your actual UI interaction if you don't use shortcuts
  await page.keyboard.press('KeyF');
  await expect(page.locator('.modal__title')).toContainText(/finances/i);

  // Navigate to Add Transaction, then close
  const addBtn = page.getByRole('button', { name: /add transaction/i });
  if (await addBtn.isVisible()) {
    await addBtn.click();
    await expect(page.getByLabel(/amount/i)).toBeVisible();
    await page.getByRole('button', { name: /close/i }).click();
  }
});
